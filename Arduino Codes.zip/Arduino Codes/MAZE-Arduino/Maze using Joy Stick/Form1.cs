﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maze_using_Joy_Stick
{
    public partial class Form1 : Form
    {
        delegate void serialCalback(string val);
        public Form1()
        {
            InitializeComponent();           
        }

       
        int xPosition;
        int yPosition;
        string result;
        int defaultX = 405;
        int defaultY = 12;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                result = serialPort1.ReadLine();
                resultData(result);
            }
        }

        private void resultData(string recieved)
        {
            if (this.textBox1.InvokeRequired)
            {
                serialCalback scb = new serialCalback(resultData);
                this.Invoke(scb, new object[] { recieved });
            }
            else
            {                
                
                string[] location = recieved.Split(' ');
                if (location.Length == 1)
                {
                    textBox1.Text = "Not Ready";
                }
                else
                {
                    textBox1.Text = "Ready";
                    xPosition = Convert.ToInt32(location[0]);
                    yPosition = Convert.ToInt32(location[1]);
                }
              
                
                if (xPosition < 10 && yPosition > 500)C:\Users\Rey Mhark\Documents\wait\New folder\New folder\Documents\Arduino\Arduino Codes\Arduino Codes\MAZE-Arduino\Maze using Joy Stick\Resources\Sample-maze-used-in-computer-simulations_finsl2.gif

                {
                    defaultX = defaultX - 1;
                    pictureBox2.Location = new System.Drawing.Point(defaultX, defaultY);
                }
                else if (xPosition == 1023 && yPosition > 500)
                {
                    defaultX = defaultX + 1;
                    pictureBox2.Location = new System.Drawing.Point(defaultX, defaultY);
                }
                else if (xPosition > 500 && yPosition < 10)
                {
                    defaultY = defaultY - 1;
                    pictureBox2.Location = new System.Drawing.Point(defaultX, defaultY);
                }
                else if (xPosition > 500 && yPosition == 1023)
                {
                    defaultY = defaultY + 1;
                    pictureBox2.Location = new System.Drawing.Point(defaultX, defaultY);
                }
            }       
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Location = new System.Drawing.Point(158, 38);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                serialPort1.Open();
            }
        }
    }
}
