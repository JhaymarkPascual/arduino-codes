﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO.Ports;
using System.Diagnostics;

namespace FTBasicCrud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
            
           
           
           
           
        }
        public string data;
        public string fname_;
         public string mname_;
         public string lname_;
         public string gender_;
         public string no_absent_;
         public string no_present_;
      public   int sec = 0;

              
        private void button4_Click(object sender, EventArgs e)
        {
           
           
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datatab = new DataTable();
            datatab = datacon.recSQL("SELECT * FROM `student`");
            record.DataSource = datatab;


            DatabaseConnection dc = new DatabaseConnection();
            DataTable dt = new DataTable();
            dt = dc.recSQL("SELECT * FROM `attendance`");
            attendance.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void extrabtn_Click(object sender, EventArgs e)
        {
            DatabaseConnection con = new DatabaseConnection();
            DataTable tab = new DataTable();
            tab = con.recSQL("SELECT * FROM `familymember`");
            record.DataSource = tab;
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
                  
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
           
        }

        private void Searchtxb_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        { 
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
           
        }

        private void Searchtxb_TextChanged(object sender, EventArgs e)
        {

        }

        private void Student_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FNametxb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Mnametxb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Lnametxb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void Agetxb_TextChanged(object sender, EventArgs e)
        {

        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datatab = new DataTable();
            if (MessageBox.Show("Are you sure", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                datatab = datacon.recSQL("INSERT INTO `student` (`user_id`, `fname`, `mname`, `lname`, `address`, `gender`, `no_absent`, `no_present`, `contact`) VALUES  ('" +user_id.Text + "','" +FNametxb.Text + "','" +Mnametxb.Text  + "','" +Lnametxb.Text + "','" + Addresstxb.Text + "','" + Gender.Text + "','" + total_absent.Text + "','" + total_present.Text + "','" + Contacttxb.Text + "')");
                MessageBox.Show("Successfully Added!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                extrabtn.PerformClick();
                Clearbtn.PerformClick();
            }
           
        }

        private void Updatebtn_Click_1(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datab = new DataTable();

            if (MessageBox.Show("Are you sure", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                datab = datacon.recSQL("UPDATE `student` SET `user_id` = '" + user_id.Text + "', `fname`= '" +FNametxb.Text + "', `mname` = '" + Mnametxb.Text + "', `lname` = '" + Lnametxb.Text + "', `address` = '" + Addresstxb.Text + "', `gender` = '" +Gender.Text + "', `no_absent` = '" + total_absent.Text + "', `no_present` = '" + total_present.Text + "', `contact` = '" + Contacttxb.Text + "' WHERE `user_id` = '"+user_id.Text+"'");
                extrabtn.PerformClick();
                MessageBox.Show("Save Successfully!!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clearbtn.PerformClick();
            }
        }

        private void Deletebtn_Click_1(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datab = new DataTable();
            if (MessageBox.Show("Are you sure", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                datab = datacon.recSQL("DELETE FROM `student` WHERE `user_id` = '" + user_id.Text + "'");
                MessageBox.Show("Delete Successfully!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                extrabtn.PerformClick();
                Clearbtn.PerformClick();
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datab = new DataTable();
            if (MessageBox.Show("Are you sure", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                datab = datacon.recSQL("DELETE FROM `student`");
                MessageBox.Show("Delete all Successfully!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                extrabtn.PerformClick();
            }
        }

        private void Clearbtn_Click_1(object sender, EventArgs e)
        {
            Lnametxb.Clear();
            Addresstxb.Clear();
            FNametxb.Clear();
            Mnametxb.Clear();
            Contacttxb.Clear();
            Gender.Text = "";
            user_id.Clear();
            total_present.Clear();
            total_absent.Clear();

        }

        private void searchbtn_Click_1(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datab = new DataTable();
            datab = datacon.recSQL("SELECT * FROM `student` WHERE `lname` LIKE '%" + Searchtxb.Text + "%' OR `mname`LIKE '%" + Searchtxb.Text + "%' OR `lname` LIKE '%" + Searchtxb.Text + "%'");
            record.DataSource = datab;
        }

        private void extrabtn_Click_1(object sender, EventArgs e)
        {
            DatabaseConnection datacon = new DatabaseConnection();
            DataTable datab = new DataTable();
            datab = datacon.recSQL("SELECT * FROM student");
            record.DataSource = datab;

        }

        private void record_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow row = this.record.Rows[e.RowIndex];

                Addresstxb.Text = row.Cells["address"].Value.ToString();
                FNametxb.Text = row.Cells["fname"].Value.ToString();
                Mnametxb.Text = row.Cells["mname"].Value.ToString();
                Lnametxb.Text = row.Cells["lname"].Value.ToString();
                Contacttxb.Text = row.Cells["contact"].Value.ToString();
                total_absent.Text = row.Cells["no_absent"].Value.ToString();
                total_present.Text = row.Cells["no_present"].Value.ToString();
                Gender.Text = row.Cells["gender"].Value.ToString();
                user_id.Text = row.Cells["user_id"].Value.ToString();
            }
        }

        private void submit_Click(object sender, EventArgs e)
        {
            
                DatabaseConnection datacon = new DatabaseConnection();
                DataTable datatab = new DataTable();

                datatab = datacon.recSQL("INSERT INTO `attendance` (`user_id`, `fname`, `mname`, `lname`,`gender`,`Date`) VALUES  ('" + id.Text.ToString().Trim() + "','" + fname.Text + "','" + mname.Text + "','" + lname.Text + "','" + sex.Text + "','" + date.Text + "')");
                datatab = datacon.recSQL("UPDATE `student` SET `no_present` = `no_present` +1 WHERE `user_id` = '" + id.Text.ToString().Trim() + "'");
                MessageBox.Show("Successfully Added!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                id.Text = "";
                fname.Clear();
                mname.Clear();
                lname.Clear();
                sex.Text = "";


                data = "";
            
          
        }
        
           
        

        private void timer1_Tick(object sender, EventArgs e)
        {
          

            date.Text = DateTime.Now.ToString();
          
         
                
                id.Text = data;
                if (id.Text != "")
                {
                    button1.PerformClick();
                   
                   
                
                   

                    DatabaseConnection dc = new DatabaseConnection();
                    DataTable dt = new DataTable();
                    dt = dc.recSQL("SELECT * FROM `attendance`");
                    attendance.DataSource = dt;
                  


                }
              
               
                

         

               
          
        }

        private void Scan_Click(object sender, EventArgs e)
        {
           
            if (Scan.Text == "Scan...")
            {
                serialPort1.Open();
                Scan.Text = "Stop...";
                Scan.BackColor = Color.Red;
                

            }
            else

            {
                serialPort1.Close();
                Scan.Text = "Scan...";
                Scan.BackColor = Color.Green;
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            data = "";
           data = serialPort1.ReadLine();
           if (data != "")
           {
               
               timer1.Start();
           }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connectionString = new MySqlConnection("datasource = 127.0.0.1; port = 3306; database = attendance_system; username=root;password=;");



            string sql = "SELECT `fname`,`mname`,`lname`,`gender`,`no_absent`,`no_present` FROM `student` WHERE user_id = '" + id.Text.ToString().Trim() +"'";
     
            connectionString.Open();
            MySqlCommand mycmd = new MySqlCommand(sql, connectionString);

            using (MySqlDataReader dr = mycmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    fname.Text = dr["fname"].ToString();
                    mname.Text = dr["mname"].ToString();
                    lname.Text = dr["lname"].ToString();
                    sex.Text = dr["gender"].ToString();
                    no_absent.Text = dr["no_absent"].ToString();
                    no_present.Text = dr["no_present"].ToString();
                   


                }
            }

        }
    }
}
