﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
namespace FTBasicCrud
{
    class DatabaseConnection
    {

        MySqlConnection mycon = new MySqlConnection();
        MySqlCommand mycmd = new MySqlCommand();
        MySqlDataAdapter adpt = new MySqlDataAdapter();
        
        public string connectionString = "datasource = 127.0.0.1; port = 3306; database = attendance_system; username=root;password=;";

        public DataTable recSQL(String SQL)
        {
            DataTable table = new DataTable();
            mycon = new MySqlConnection(connectionString);
            mycmd = new MySqlCommand();
            adpt = new MySqlDataAdapter();

            mycon.Open();
            mycmd.Connection = mycon;
            mycmd.CommandText = SQL;
            adpt.SelectCommand = mycmd;
            adpt.Fill(table);
            table.Dispose();
            mycon.Close();
            return table;
        }
    }
}
