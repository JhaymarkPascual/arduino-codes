-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2021 at 09:05 AM
-- Server version: 5.5.42-log
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `family_tree`
--

-- --------------------------------------------------------

--
-- Table structure for table `familymember`
--

CREATE TABLE `familymember` (
  `DataNo` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `MiddleInitial` varchar(11) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Age` varchar(20) DEFAULT NULL,
  `Relationship` varchar(50) DEFAULT NULL,
  `ContactNo` varchar(50) DEFAULT NULL,
  `Occupation` varchar(50) DEFAULT NULL,
  `Religion` varchar(20) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `familymember`
--

INSERT INTO `familymember` (`DataNo`, `FirstName`, `MiddleInitial`, `LastName`, `Age`, `Relationship`, `ContactNo`, `Occupation`, `Religion`, `Status`, `Address`, `Gender`) VALUES
(14, 'Angelo', 'Pedragoza', 'Mayuga', '19', 'Son', '09278204051', 'None', 'Roman-Chatolic', 'Single', 'Bagong Buhay Victoria Oriental Mindoro', 'Male'),
(15, 'Argie', 'Pedragoza', 'Mayuga', '25', 'Son', '099999999', 'Employee', 'Roman-Catolic', 'Married', 'Bagong Buhay', 'Male'),
(16, 'Lucia ', 'Pedragoza', 'Mayuga', '50', 'Mother', 'none', 'Housewife', 'Roman-Catolic', 'Married', 'Bagong Buhay', 'Female'),
(17, 'Daniel', 'Pedragoza', 'Mayuga', '56', 'Father', 'none', 'Farmer', 'Roman Catolic', 'Married', 'Bagong Buhay', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `familymember`
--
ALTER TABLE `familymember`
  ADD PRIMARY KEY (`DataNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `familymember`
--
ALTER TABLE `familymember`
  MODIFY `DataNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
